# -*- coding: utf-8 -*-

from . import account_asset
from . import asset_marker
from . import res_partner
